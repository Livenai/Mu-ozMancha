#ifndef CONFIG_H
#define CONFIG_H

// Comment out this line if your application has a QtGui
#define USE_QTGUI


#define PROGRAM_NAME    "MyFirstComp"
#define SERVER_FULL_NAME   "RoboComp MyFirstComp:: MyFirstComp"

#endif
